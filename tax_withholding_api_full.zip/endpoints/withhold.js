const getRegionFromIP = require('../utils/ipLookup');
const fallbackRegionFromMAC = require('../utils/macFallback');
const calculateTax = require('../utils/calculateTax');
const sendTaxToWallet = require('../utils/taxWalletManager');

module.exports = async (req, res) => {
  const { amount, currency, ip, mac } = req.body;
  let regionInfo;

  try {
    regionInfo = await getRegionFromIP(ip);
  } catch {
    regionInfo = fallbackRegionFromMAC(mac);
  }

  const { taxAmount, rate } = calculateTax(regionInfo.country, regionInfo.region, amount);
  const txResult = await sendTaxToWallet(currency, taxAmount);

  res.json({ region: regionInfo, taxRate: rate, taxAmount, transaction: txResult });
};