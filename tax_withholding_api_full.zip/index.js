const express = require('express');
const bodyParser = require('body-parser');
const withhold = require('./endpoints/withhold');
const generateFiling = require('./endpoints/generateFiling');

const app = express();
app.use(bodyParser.json());

app.post('/withhold-tax', withhold);
app.post('/generate-tax-filing', generateFiling);

app.listen(3000, () => console.log('Tax API running on port 3000'));