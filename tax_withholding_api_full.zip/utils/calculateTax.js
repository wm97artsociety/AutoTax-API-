const taxRates = require('../config/tax-rates.json');

module.exports = function calculateTax(country, region, amount) {
  const countryRates = taxRates[country] || {};
  const rate = countryRates[region] || countryRates.default || 0;
  return { taxAmount: amount * rate, rate };
};