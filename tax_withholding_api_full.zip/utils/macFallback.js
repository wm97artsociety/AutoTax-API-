module.exports = function fallbackRegionFromMAC(mac) {
  return { country: 'US', region: 'CA' }; // Mock fallback
};