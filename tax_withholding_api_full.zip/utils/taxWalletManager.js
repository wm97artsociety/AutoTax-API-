module.exports = async function sendTaxToWallet(currency, amount) {
  console.log(`Simulate sending ${amount} ${currency} to tax wallet.`);
  return { success: true, txHash: '0xMockTransaction' };
};