const axios = require('axios');
module.exports = async function getRegionFromIP(ip) {
  const res = await axios.get(`https://ipapi.co/${ip}/json/`);
  return { country: res.data.country, region: res.data.region_code };
};